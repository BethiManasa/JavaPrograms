package Java2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;

public class Removeelement {

	public static void main(String[] args) {
		int a[]= {1,2,4,2,5,4,3};
//		String s="Kiran Kumar Kiran";
//		LinkedHashSet<Integer> set1 = new LinkedHashSet<Integer>();
//		LinkedHashSet<Integer> set2 = new LinkedHashSet<Integer>();
//		for(int i=0;i<a.length-1;i++)
//			set1.add(a[i]);
//		System.out.println(set1);
//		List l= new ArrayList<Integer>(set1);
//		Collections.sort(l);
//		
		Arrays.sort(a);
		System.out.println(a);
	}

}
