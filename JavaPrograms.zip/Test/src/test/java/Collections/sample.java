	package Collections;

public class sample {

	public static void main(String[] args) {
		String s="Manasa";
        //	char[] x=s.toCharArray();
		for(int z=0;z<s.length();z++) {
			System.out.println(s.charAt(z));
		}

	}

}
