package Collections;

public class Hashmap {

}
