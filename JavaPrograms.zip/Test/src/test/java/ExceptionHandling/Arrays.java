package ExceptionHandling;

public class Arrays {

	public static void main(String[] args) {
		
	}

}