package ExceptionHandling;

public class ThreadSleep {

	public static void main(String[] args) throws InterruptedException {
		System.out.println("program is started....");
		System.out.println("program is in progress....");
		Thread.sleep(5000);
		System.out.println("program is finished....");
		System.out.println("program is terminated....");
		
	}

}
