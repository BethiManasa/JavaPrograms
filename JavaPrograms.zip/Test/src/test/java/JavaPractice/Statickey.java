package JavaPractice;

public class Statickey {
	public  static void k() {
		System.out.println("ccccccccccc");
	}
	public static void main(String[] args) {
		
      k();
	}

}
