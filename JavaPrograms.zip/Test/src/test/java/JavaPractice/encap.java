package JavaPractice;

public class encap {
	
	private int a;
	private char c;
	private String s;
	public int getA() {
		return a;
	}
	public void setA(int a) {
		this.a = a;
	}
	public char getC() {
		return c;
	}
	public void setC(char c) {
		this.c = c;
	}
	public String getS() {
		return s;
	}
	public void setS(String s) {
		this.s = s;
	}

}
