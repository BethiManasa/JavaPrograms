package JavaPractice;

public class class2 {

	public static void main(String[] args) {
		class1 cs = new class1();
		cs.display();
		System.out.println("Access display method from another class");
		
		

	}

}
