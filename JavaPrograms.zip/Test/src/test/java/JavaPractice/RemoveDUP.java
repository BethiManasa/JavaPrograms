package JavaPractice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class RemoveDUP {

	public static void main(String[] args) {
		
	
		int a[]= {1,2,3,2,3,4,4,4};
		
		
		
		

	}

}
