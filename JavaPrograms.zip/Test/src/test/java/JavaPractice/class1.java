package JavaPractice;

public class class1 {
	
	int id=1;
	String Name="Kumar";
	String Address="BLR";
	public void display() {
		System.out.println(id+" "+Name+" "+Address);
	}

	public static void main(String[] args) {
		class1 cs = new class1();
		cs.display();
		
	}
	
	

}
