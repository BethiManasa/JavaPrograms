package JavaPractice;

public class encapmain {

	public static void main(String[] args) {
		encap EP = new encap();
		EP.setA(5);
		System.out.println(EP.getA());
		EP.setC('K');
		System.out.println(EP.getC());
		EP.setS("Kiran");
		System.out.println(EP.getS());

	}

}
