package JavaPractice;

public class String1 {

	public static void main(java.lang.String[] args) {
		System.out.println("Hello Kiran");
		
	String x=" Kirann ";
	int i=0;
//	for(char c:x.toCharArray()) {
//		i++;
//	}
//	System.out.println(i);
//	}
	System.out.println(x.trim().toCharArray().length);
	int c=65;
	System.out.println(c+100);
	String f=String.valueOf(c);
	System.out.println(f+100);
	
	
	
	
	}
	
	
}
