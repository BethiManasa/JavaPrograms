package Java;

import java.util.Arrays;

public class SOrting {

	public static void main(String[] args) {
		int[] a = {1,-9,8,5,4};
		
		Arrays.sort(a);

		
		
		 for(int k=0;k<a.length;k++){
		 System.out.print(a[k]+" "); }
		 
		  }
		 
	}
		
