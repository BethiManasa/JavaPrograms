package Java;

public class ReverseArray {

	public static void main(String[] args) {
		int a[]= {2,3,4};
	
		int x= a.length;
		
		for(int i=x-1;i>=0;i--) {
			System.out.println(a[i]);
		}

	}

}
