package Java;

public class Loop {

	public static void main(String[] args) {
		/*int i;
		for(i=25;i<=100;) {
			System.out.println(i);
			i=i+25;
		}
		////////////////////////Even Number////////////////
		int x=12;
		if(x%2==0) {
			System.out.println("Even Number :" +x);
		}
		else {
			System.out.println("odd Number" +x);
		}
		*/
		/////////
		
		

	}

}
