package Java;

public class Palindrome {

	public static void main(String[] args) {
		
		
		int b=121;
		int x=b;
		
		int rev=0;
		while(x!=0) {
			int rem=x%10;
			rev=rev*10+rem;
			x=x/10;
		}
		
		if(b==rev)
		System.out.println("Palindrome");
		else {
			System.out.println("not Palinder");
		}
	}

}
