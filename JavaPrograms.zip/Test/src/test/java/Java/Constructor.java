package Java;

public class Constructor {
int x;
	
  Constructor(){
	   x=10;
	  
  }
	public static void main(String[] args) {
		
		Constructor c = new Constructor();
		
       System.out.println(c.x);
	}

}
