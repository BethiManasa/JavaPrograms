package Java;

import java.util.Scanner;

public class LiftProgram {

	public static void main(String[] args) {
		/*5 floors
		person 1- at 2nd floor
		person 2- at 4th floor
		1-->2-->4-->5*/
		
		r P2");Scanner sc = new Scanner(System.in);
		System.out.println("enter P1");
		int P1 =sc.nextInt();
		System.out.println("ente
		int P2 =sc.nextInt();
		for(int i=1;i<=5;i++) {
			if(P1==2)
		}

	}

}
