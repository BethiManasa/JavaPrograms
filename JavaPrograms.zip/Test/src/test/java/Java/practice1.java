package Java;

public class practice1 {

	public static void main(String[] args) {
		String s="20";
		System.out.println(Integer.parseInt(s));
		System.out.println(s);
		int x=153;
		int c= String.valueOf(x).length();
		System.out.println(c);
		
	}

}
