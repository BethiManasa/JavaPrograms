package Java;

public class SearchElement {

	public static void main(String[] args) {
		//int a[]= new int[5];
		int b[]= {10,20,30,40};
		int k= 30;
		for(int x=0;x<b.length;x++) {
			if(b[x]==k) {
				
				System.out.println("element  "+k +"is present at  " +x);
				
			}
		}

	}

}
