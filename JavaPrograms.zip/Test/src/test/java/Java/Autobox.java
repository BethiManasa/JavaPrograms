package Java;

import java.util.ArrayList;

public class Autobox {

	public static void main(String[] args) {
	
		
		int a=12;
		Integer i = new Integer(a);
		System.out.println(i);
		
		

	}

}
