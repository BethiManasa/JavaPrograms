package Java;

public class a2c3 {

	public static void main(String[] args) {
		String str ="a2b3v6";
		for(int i=1;i<str.length();i=i+2) {
			//System.out.println(str.charAt(i));
			int x =str.charAt(i);
			for(int j=0;j<=x;j++) {
				System.out.print(str.charAt(j));
				
			}
			
	}

	}

}
