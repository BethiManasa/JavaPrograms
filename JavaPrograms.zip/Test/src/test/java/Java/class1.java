package Java;

public class class1 {

	public static void main(String[] args) {
//		for(int i=1;i<=20;i++) {
//			if(i==15||i==16||i==17||i==18) {
//				break;
//			}
//			System.out.println(i);
//		}
		
////////////////////pattern//////////////
// for (int i=1;i<10;i++) {
//	 for (int j=1;j<=i;j++) {
//		 System.out.print(i);
//	 }
//	System.out.println(); 
// }
 
 
 ////////////////////pattern////////// 
// for (int i=1;i<=6;i++) {
//	 for( int j=1;j<=6-i;j++) {
//		 System.out.print(" ");
//	 }
//	 for( int k=1;k<=i;k++) {
//		 System.out.print(i+" ");
//	 }
//	 System.out.println();
// }
// 
		
		
	}

}
