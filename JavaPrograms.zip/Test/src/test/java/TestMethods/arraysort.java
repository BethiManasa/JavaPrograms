package TestMethods;

import java.util.Arrays;

public class arraysort {

	public static void main(String[] args) {
		int[] a = { 1, 2, 0, -1, -2 };
         String k="kiran Kuamr puli";
         String str="";
//		for (int i = 0; i < a.length; i++) {
//			for (int j = i + 1; j < a.length; j++) {
//				if (a[i] > a[j]) {
//					int d = a[i];
//					a[i] = a[j];
//					a[j] = d;
//				}
//			}
//
//		}
//		for (int k = 0; k < a.length; k++) {
//			System.out.println(a[k]);
//		}
   
         
         for(int i=k.length();i<=0;i--) {
        	 str=str+k.charAt(i);         }
         System.out.println(str);
	}
	
}
